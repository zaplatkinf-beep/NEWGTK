/*
 *  server_example_logging.c
 *
 *  - How to use a server with logging service
 *  - How to store arbitrary data in a log
 *
 */

#include "iec61850_server.h"
#include "hal_thread.h"
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

#include "static_model.h"

#include "logging_api.h"

static int running = 0;
static IedServer iedServer = NULL;
static LogStorage statusLog = NULL;

void
sigint_handler(int signalId)
{
    running = 0;
}

static ControlHandlerResult
controlHandlerForBinaryOutput(ControlAction action, void* parameter, MmsValue* value, bool test)
{
    if (test) {
        printf("Received test command\n");
        return CONTROL_RESULT_FAILED;
    }

    if (MmsValue_getType(value) == MMS_BOOLEAN) {
        printf("received binary control command: ");

        if (MmsValue_getBoolean(value))
            printf("on\n");
        else
            printf("off\n");
    }
    else
        return CONTROL_RESULT_FAILED;

    uint64_t timeStamp = Hal_getTimeInMs();

    if (parameter == IEDMODEL_GenericIO_GGIO1_SPCSO1) {
        IedServer_updateUTCTimeAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_SPCSO1_t, timeStamp);
        IedServer_updateAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_SPCSO1_stVal, value);
        

        uint64_t entryID = LogStorage_addEntry(statusLog, timeStamp);
        uint8_t blob[256];
        int blobSize = MmsValue_encodeMmsData(value, blob, 0, true);
        LogStorage_addEntryData(statusLog, entryID, "GenericIO/GGIO1$ST$SPCSO1$stVal", blob, blobSize, 0);
        printf("Added log entry for SPCSO1 change\n");
    }

    if (parameter == IEDMODEL_GenericIO_GGIO1_SPCSO2) {
        IedServer_updateUTCTimeAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_SPCSO2_t, timeStamp);
        IedServer_updateAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_SPCSO2_stVal, value);
        
        uint64_t entryID = LogStorage_addEntry(statusLog, timeStamp);
        uint8_t blob[256];
        int blobSize = MmsValue_encodeMmsData(value, blob, 0, true);
        LogStorage_addEntryData(statusLog, entryID, "GenericIO/GGIO1$ST$SPCSO2$stVal", blob, blobSize, 0);
        printf("Added log entry for SPCSO2 change\n");
    }

    if (parameter == IEDMODEL_GenericIO_GGIO1_SPCSO3) {
        IedServer_updateUTCTimeAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_SPCSO3_t, timeStamp);
        IedServer_updateAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_SPCSO3_stVal, value);
        
        uint64_t entryID = LogStorage_addEntry(statusLog, timeStamp);
        uint8_t blob[256];
        int blobSize = MmsValue_encodeMmsData(value, blob, 0, true);
        LogStorage_addEntryData(statusLog, entryID, "GenericIO/GGIO1$ST$SPCSO3$stVal", blob, blobSize, 0);
        printf("Added log entry for SPCSO3 change\n");
    }

    if (parameter == IEDMODEL_GenericIO_GGIO1_SPCSO4) {
        IedServer_updateUTCTimeAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_SPCSO4_t, timeStamp);
        IedServer_updateAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_SPCSO4_stVal, value);
        
        uint64_t entryID = LogStorage_addEntry(statusLog, timeStamp);
        uint8_t blob[256];
        int blobSize = MmsValue_encodeMmsData(value, blob, 0, true);
        LogStorage_addEntryData(statusLog, entryID, "GenericIO/GGIO1$ST$SPCSO4$stVal", blob, blobSize, 0);
        printf("Added log entry for SPCSO4 change\n");
    }

    return CONTROL_RESULT_OK;
}

static void
connectionHandler (IedServer self, ClientConnection connection, bool connected, void* parameter)
{
    if (connected)
        printf("Connection opened - client connected\n");
    else
        printf("Connection closed - client disconnected\n");
}

static bool
entryCallback(void* parameter, uint64_t timestamp, uint64_t entryID, bool moreFollow)
{
    if (moreFollow)
        printf("Log entry - ID: %llu, timestamp: %llu\n", 
               (unsigned long long)entryID, (unsigned long long)timestamp);
    return true;
}

static bool
entryDataCallback (void* parameter, const char* dataRef, const uint8_t* data, int dataSize, uint8_t reasonCode, bool moreFollow)
{
    if (moreFollow) {
        printf("  Log data - ref: %s, reason: %d\n", dataRef, reasonCode);
    }
    return true;
}


static void
addTestLogEntry(uint64_t timestamp, const char* dataRef, MmsValue* value)
{
    uint64_t entryID = LogStorage_addEntry(statusLog, timestamp);
    uint8_t blob[256];
    int blobSize = MmsValue_encodeMmsData(value, blob, 0, true);
    LogStorage_addEntryData(statusLog, entryID, dataRef, blob, blobSize, 0);
    

    MmsValue* timeValue = MmsValue_newUtcTimeByMsTime(timestamp);
    blobSize = MmsValue_encodeMmsData(timeValue, blob, 0, true);
    char timeRef[100];
    snprintf(timeRef, 100, "%s$t", dataRef);
    LogStorage_addEntryData(statusLog, entryID, timeRef, blob, blobSize, 0);
    MmsValue_delete(timeValue);
    
    printf("Added log entry: %s\n", dataRef);
}
int
main(int argc, char** argv)
{
    int tcpPort = 102;

    if (argc > 1) {
        tcpPort = atoi(argv[1]);
    }

    printf("Using libIEC61850 version %s\n", LibIEC61850_getVersionString());
    printf("Starting IEC 61850 server on port %d\n", tcpPort);
    printf("Press Ctrl+C to stop the server\n");

    iedServer = IedServer_create(&iedModel);

    if (iedServer == NULL) {
        printf("Failed to create IED server!\n");
        return -1;
    }


    IedServer_setControlHandler(iedServer, IEDMODEL_GenericIO_GGIO1_SPCSO1,
            (ControlHandler) controlHandlerForBinaryOutput,
            IEDMODEL_GenericIO_GGIO1_SPCSO1);

    IedServer_setControlHandler(iedServer, IEDMODEL_GenericIO_GGIO1_SPCSO2,
            (ControlHandler) controlHandlerForBinaryOutput,
            IEDMODEL_GenericIO_GGIO1_SPCSO2);

    IedServer_setControlHandler(iedServer, IEDMODEL_GenericIO_GGIO1_SPCSO3,
            (ControlHandler) controlHandlerForBinaryOutput,
            IEDMODEL_GenericIO_GGIO1_SPCSO3);

    IedServer_setControlHandler(iedServer, IEDMODEL_GenericIO_GGIO1_SPCSO4,
            (ControlHandler) controlHandlerForBinaryOutput,
            IEDMODEL_GenericIO_GGIO1_SPCSO4);

    IedServer_setConnectionIndicationHandler(iedServer, (IedConnectionIndicationHandler) connectionHandler, NULL);


    statusLog = SqliteLogStorage_createInstance("log_status.db");

    if (statusLog == NULL) {
        printf("Failed to create log storage!\n");
        IedServer_destroy(iedServer);
        return -1;
    }

    LogStorage_setMaxLogEntries(statusLog, 1000); 

    IedServer_setLogStorage(iedServer, "GenericIO/LLN0$EventLog", statusLog);
    printf("Log storage configured for: GenericIO/LLN0$EventLog\n");

    IedServer_updateBooleanAttributeValue(iedServer, IEDMODEL_GenericIO_LLN0_Health_stVal, true);
    printf("Logging enabled by default\n");

    uint64_t initialTime = Hal_getTimeInMs();
    
    MmsValue* initValue = MmsValue_newIntegerFromInt32(9999);
    addTestLogEntry(initialTime, "GenericIO/GGIO1$ST$SPCSO1$stVal", initValue);
    MmsValue_delete(initValue);
    
    initValue = MmsValue_newBoolean(false);
    addTestLogEntry(initialTime + 1000, "GenericIO/GGIO1$ST$SPCSO2$stVal", initValue);
    MmsValue_delete(initValue);
    
    initValue = MmsValue_newFloat(3.14f);
    addTestLogEntry(initialTime + 2000, "GenericIO/GGIO1$MX$AnIn1$mag$f", initValue);
    MmsValue_delete(initValue);


    IedServer_start(iedServer, tcpPort);

    if (!IedServer_isRunning(iedServer)) {
        printf("Starting server failed! Exit.\n");
        IedServer_destroy(iedServer);
        LogStorage_destroy(statusLog);
        return -1;
    }

    printf("Server is running and waiting for connections...\n");
    printf("Available data points:\n");
    printf("  - GenericIO/GGIO1.SPCSO1 (binary output)\n");
    printf("  - GenericIO/GGIO1.SPCSO2 (binary output)\n");
    printf("  - GenericIO/GGIO1.SPCSO3 (binary output)\n");
    printf("  - GenericIO/GGIO1.SPCSO4 (binary output)\n");
    printf("  - GenericIO/GGIO1.AnIn1 (analog input)\n");
    printf("  - GenericIO/GGIO1.AnIn2 (analog input)\n");
    printf("  - GenericIO/GGIO1.AnIn3 (analog input)\n");
    printf("  - GenericIO/GGIO1.AnIn4 (analog input)\n");
    printf("Log: GenericIO/LLN0.EventLog\n");


    running = 1;
    signal(SIGINT, sigint_handler);

    float t = 0.f;
    int updateCounter = 0;
    int logCounter = 0;


    while (running) {
        uint64_t timestamp = Hal_getTimeInMs();

        t += 0.1f;

        float an1 = sinf(t);
        float an2 = sinf(t + 1.f);
        float an3 = sinf(t + 2.f);
        float an4 = sinf(t + 3.f);

        IedServer_lockDataModel(iedServer);

        Timestamp iecTimestamp;

        Timestamp_clearFlags(&iecTimestamp);
        Timestamp_setTimeInMilliseconds(&iecTimestamp, timestamp);
        Timestamp_setLeapSecondKnown(&iecTimestamp, true);

        if (((int) t % 2) == 0)
            Timestamp_setClockNotSynchronized(&iecTimestamp, true);

        IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_AnIn1_t, &iecTimestamp);
        IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_AnIn1_mag_f, an1);

        IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_AnIn2_t, &iecTimestamp);
        IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_AnIn2_mag_f, an2);

        IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_AnIn3_t, &iecTimestamp);
        IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_AnIn3_mag_f, an3);

        IedServer_updateTimestampAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_AnIn4_t, &iecTimestamp);
        IedServer_updateFloatAttributeValue(iedServer, IEDMODEL_GenericIO_GGIO1_AnIn4_mag_f, an4);

        IedServer_unlockDataModel(iedServer);


        if (updateCounter % 50 == 0) {
            MmsValue* logValue = MmsValue_newFloat(an1);
            addTestLogEntry(timestamp, "GenericIO/GGIO1$MX$AnIn1$mag$f", logValue);
            MmsValue_delete(logValue);
            
            logValue = MmsValue_newFloat(an2);
            addTestLogEntry(timestamp + 100, "GenericIO/GGIO1$MX$AnIn2$mag$f", logValue);
            MmsValue_delete(logValue);
            
            logCounter++;
            printf("Periodic log update #%d - AnIn1: %.3f, AnIn2: %.3f\n", logCounter, an1, an2);
        }

        Thread_sleep(100);
        updateCounter++;
        
        if (updateCounter % 300 == 0) {
            printf("Server running - %d updates, %d log entries added\n", updateCounter, logCounter);
        }
    }

    printf("\nStopping server...\n");
    
    /* stop MMS server - close TCP server socket and all client sockets */
    IedServer_stop(iedServer);

    /* Cleanup - free all resources */
    IedServer_destroy(iedServer);

    /* Release connection to database and free resources */
    LogStorage_destroy(statusLog);
    
    printf("Server stopped successfully\n");
    return 0;
}
