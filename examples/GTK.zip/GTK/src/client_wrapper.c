#define _GNU_SOURCE
#include "client_wrapper.h"
#include "iec61850_client.h"
#include "hal_thread.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <stdint.h>
#include <ctype.h>

static IedConnection g_con = NULL;
static pthread_t g_client_thread = 0;
static volatile int g_running = 0;
static char g_current_log_ref[256] = "";

static void (*g_log_callback)(const char*) = NULL;
static void (*g_log_entry_full_callback)(LogEntryFullWrapper*) = NULL;
static void (*g_model_node_callback)(void*, const char*, const char*) = NULL;
static void (*g_log_status_callback)(const char*) = NULL;
static void (*g_log_ref_callback)(const char*) = NULL;

// Установка callback'ов
void client_set_log_callback(void (*callback)(const char*)) { g_log_callback = callback; }
void client_set_log_entry_full_callback(void (*callback)(LogEntryFullWrapper*)) {
    g_log_entry_full_callback = callback;
}
void client_set_model_node_callback(void (*callback)(void*, const char*, const char*)) { g_model_node_callback = callback; }
void client_set_log_status_callback(void (*callback)(const char*)) { g_log_status_callback = callback; }
void client_set_log_ref_callback(void (*callback)(const char*)) { g_log_ref_callback = callback; }

// Вспомогательная функция логирования
static void client_log(const char* format, ...) {
    if (!g_log_callback) return;
    char buffer[1024];
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    g_log_callback(buffer);
}

// Обход модели данных (рекурсивный) и отправка узлов в GUI
static void browse_data_directory(const char* ref, IedConnection con, void* parent, int spaces) {
    IedClientError error;
    LinkedList attrs = IedConnection_getDataDirectory(con, &error, ref);
    if (attrs) {
        LinkedList node = LinkedList_getNext(attrs);
        while (node) {
            char* name = (char*)node->data;
            char fullRef[512];
            snprintf(fullRef, sizeof(fullRef), "%s.%s", ref, name);
            if (g_model_node_callback)
                g_model_node_callback(parent, name, "DA");
            browse_data_directory(fullRef, con, parent, spaces+2);
            node = LinkedList_getNext(node);
        }
        LinkedList_destroy(attrs);
    }
}

// Запрос модели устройства
static void* model_thread_func(void* arg) {
    if (!g_con) {
        client_log("Нет подключения для запроса модели");
        return NULL;
    }
    IedClientError error;
    client_log("Начало обхода модели данных...");

    LinkedList deviceList = IedConnection_getLogicalDeviceList(g_con, &error);
    if (error != IED_ERROR_OK) {
        client_log("Ошибка получения списка устройств: %d", error);
        return NULL;
    }
    LinkedList device = LinkedList_getNext(deviceList);
    while (device) {
        char* ldName = (char*)device->data;
        if (g_model_node_callback)
            g_model_node_callback(NULL, ldName, "LD");
        LinkedList nodes = IedConnection_getLogicalDeviceDirectory(g_con, &error, ldName);
        LinkedList ln = LinkedList_getNext(nodes);
        while (ln) {
            char* lnName = (char*)ln->data;
            char lnRef[256];
            snprintf(lnRef, sizeof(lnRef), "%s/%s", ldName, lnName);
            if (g_model_node_callback)
                g_model_node_callback(NULL, lnName, "LN");
            LinkedList dataObjects = IedConnection_getLogicalNodeDirectory(g_con, &error, lnRef, ACSI_CLASS_DATA_OBJECT);
            LinkedList dobj = LinkedList_getNext(dataObjects);
            while (dobj) {
                char* doName = (char*)dobj->data;
                char doRef[256];
                snprintf(doRef, sizeof(doRef), "%s/%s.%s", ldName, lnName, doName);
                if (g_model_node_callback)
                    g_model_node_callback(NULL, doName, "DO");
                browse_data_directory(doRef, g_con, NULL, 0);
                dobj = LinkedList_getNext(dobj);
            }
            LinkedList_destroy(dataObjects);
            ln = LinkedList_getNext(ln);
        }
        LinkedList_destroy(nodes);
        device = LinkedList_getNext(device);
    }
    LinkedList_destroy(deviceList);
    client_log("Обход модели завершён");
    return NULL;
}

// Форматирование времени из формата сервера в "YYYY.MM.DD HH:MM:SS.ms"
static void format_timestamp(const char* src, char* dst, size_t dst_size) {
    if (!src || src[0] == '\0') {
        strncpy(dst, "N/A", dst_size);
        return;
    }
    // Формат "20260417094837.051Z"
    if (strlen(src) >= 19 && isdigit(src[0]) && src[15] == '.') {
        snprintf(dst, dst_size, "%.4s.%.2s.%.2s %.2s:%.2s:%.2s.%s",
                 src, src+4, src+6, src+8, src+10, src+12, src+15);
        char *z = strchr(dst, 'Z');
        if (z) *z = '\0';
        return;
    }
    strncpy(dst, src, dst_size);
    dst[dst_size-1] = '\0';
}

// Преобразование ReasonCode (строка "0000000") в читаемый текст
static const char* reason_code_to_string(const char* rc) {
    if (!rc || strlen(rc) == 0 || strcmp(rc, "0000000") == 0 || strcmp(rc, "0") == 0)
        return "По умолчанию";
    if (strlen(rc) >= 7) {
        if (rc[6] == '1') return "Изменение данных";
        if (rc[5] == '1') return "Изменение качества";
        if (rc[4] == '1') return "Обновление данных";
        if (rc[3] == '1') return "Периодический";
        if (rc[2] == '1') return "Общий опрос";
    }
    return rc;
}

// Извлечение источника события (часть до последнего $ или .)
static void extract_source(const char* tag, char* dst, size_t dst_size) {
    const char* last = strrchr(tag, '$');
    if (!last) last = strrchr(tag, '.');
    if (last && last > tag) {
        size_t len = last - tag;
        if (len < dst_size - 1) {
            strncpy(dst, tag, len);
            dst[len] = '\0';
        } else {
            strncpy(dst, tag, dst_size - 1);
        }
    } else {
        strncpy(dst, tag, dst_size - 1);
    }
}

// Извлечение описания (последняя часть после $ или .)
static void extract_description(const char* tag, char* dst, size_t dst_size) {
    const char* last = strrchr(tag, '$');
    if (!last) last = strrchr(tag, '.');
    if (!last) last = strrchr(tag, '/');
    if (last && *(last + 1)) {
        const char* start = last + 1;
        int i = 0;
        while (start[i] && start[i] != '$' && start[i] != '.' && start[i] != '/' && i < (int)dst_size - 1) {
            dst[i] = start[i];
            i++;
        }
        dst[i] = '\0';
    } else {
        strncpy(dst, tag, dst_size - 1);
    }
}

// Автоопределение журнала
void client_detect_logs(void) {
    if (!g_con) {
        client_log("Нет подключения");
        if (g_log_status_callback) g_log_status_callback("Ошибка: нет подключения");
        return;
    }
    IedClientError error;
    LinkedList deviceList = IedConnection_getLogicalDeviceList(g_con, &error);
    if (error != IED_ERROR_OK) {
        client_log("Ошибка получения списка устройств");
        return;
    }
    char foundLogRef[256] = "";
    LinkedList device = LinkedList_getNext(deviceList);
    while (device && foundLogRef[0]==0) {
        char* ld = (char*)device->data;
        LinkedList nodes = IedConnection_getLogicalDeviceDirectory(g_con, &error, ld);
        LinkedList ln = LinkedList_getNext(nodes);
        while (ln && foundLogRef[0]==0) {
            char* lnName = (char*)ln->data;
            char lnRef[256];
            snprintf(lnRef, sizeof(lnRef), "%s/%s", ld, lnName);
            LinkedList logs = IedConnection_getLogicalNodeDirectory(g_con, &error, lnRef, ACSI_CLASS_LOG);
            LinkedList log = LinkedList_getNext(logs);
            while (log && foundLogRef[0]==0) {
                char* logName = (char*)log->data;
                if (strstr(logName, "EventLog") != NULL || strstr(logName, "Log") != NULL) {
                    snprintf(foundLogRef, sizeof(foundLogRef), "%s/%s$%s", ld, lnName, logName);
                }
                log = LinkedList_getNext(log);
            }
            LinkedList_destroy(logs);
            ln = LinkedList_getNext(ln);
        }
        LinkedList_destroy(nodes);
        device = LinkedList_getNext(device);
    }
    LinkedList_destroy(deviceList);
    if (foundLogRef[0]) {
        strcpy(g_current_log_ref, foundLogRef);
        if (g_log_ref_callback) g_log_ref_callback(foundLogRef);
        if (g_log_status_callback) g_log_status_callback("Журнал найден");
        client_log("Найден журнал: %s", foundLogRef);
    } else {
        if (g_log_status_callback) g_log_status_callback("Журналы не найдены");
        client_log("Журналы не найдены");
    }
}

// Включение/выключение журнала
void client_enable_log(const char* logRef) {
    if (!g_con || !logRef) return;
    IedClientError error;
    char logEnaRef[512];
    strncpy(logEnaRef, logRef, sizeof(logEnaRef)-1);
    char *p = strrchr(logEnaRef, '$');
    if (p) *p = '.';
    strncat(logEnaRef, ".LogEna", sizeof(logEnaRef)-strlen(logEnaRef)-1);
    IedConnection_writeBooleanValue(g_con, &error, logEnaRef, IEC61850_FC_LG, true);
    if (error == IED_ERROR_OK) {
        client_log("Журнал %s включён", logRef);
        if (g_log_status_callback) g_log_status_callback("Журнал включён");
    } else {
        client_log("Ошибка включения журнала: %d", error);
    }
}

void client_disable_log(const char* logRef) {
    if (!g_con || !logRef) return;
    IedClientError error;
    char logEnaRef[512];
    strncpy(logEnaRef, logRef, sizeof(logEnaRef)-1);
    char *p = strrchr(logEnaRef, '$');
    if (p) *p = '.';
    strncat(logEnaRef, ".LogEna", sizeof(logEnaRef)-strlen(logEnaRef)-1);
    IedConnection_writeBooleanValue(g_con, &error, logEnaRef, IEC61850_FC_LG, false);
    if (error == IED_ERROR_OK) {
        client_log("Журнал %s выключен", logRef);
        if (g_log_status_callback) g_log_status_callback("Журнал выключен");
    } else {
        client_log("Ошибка выключения журнала: %d", error);
    }
}

void client_query_all_logs(const char* logRef) {
    if (!g_con || !logRef) {
        client_log("Ошибка: нет подключения или LogRef");
        return;
    }

    IedClientError error;

    // Включаем журнал (LogEna)
    char logEnaRef[512];
    strncpy(logEnaRef, logRef, sizeof(logEnaRef) - 1);
    char *p = strrchr(logEnaRef, '$');
    if (p) *p = '.';
    strncat(logEnaRef, ".LogEna", sizeof(logEnaRef) - strlen(logEnaRef) - 1);
    IedConnection_writeBooleanValue(g_con, &error, logEnaRef, IEC61850_FC_LG, true);
    if (error != IED_ERROR_OK)
        client_log("Предупреждение: не удалось включить журнал: %d", error);
    Thread_sleep(500);

    // Читаем LCB (Log Control Block)
    char logCbRef[512];
    strcpy(logCbRef, logEnaRef);
    char *dot = strrchr(logCbRef, '.');
    if (dot) *dot = '\0';
    MmsValue* lcbValue = IedConnection_readObject(g_con, &error, logCbRef, IEC61850_FC_LG);
    if (error != IED_ERROR_OK || !lcbValue) {
        client_log("Ошибка чтения LCB: %d", error);
        if (g_log_status_callback) g_log_status_callback("Ошибка чтения LCB");
        return;
    }

    MmsValue* oldEntry = MmsValue_getElement(lcbValue, 5);
    MmsValue* oldEntryTm = MmsValue_getElement(lcbValue, 3);
    uint64_t timestamp = oldEntryTm ? MmsValue_getUtcTimeInMs(oldEntryTm) : 0;

    bool more = true;
    int totalEntries = 0;
    int queryCount = 0;
    MmsValue* lastEntry = NULL;
    uint64_t lastTimestamp = 0;

    while (more) {
        queryCount++;
        LinkedList entries = IedConnection_queryLogAfter(g_con, &error, logRef,
                                    lastEntry ? lastEntry : oldEntry,
                                    lastEntry ? lastTimestamp : timestamp,
                                    &more);
        if (error != IED_ERROR_OK) {
            client_log("Ошибка запроса журнала: %d", error);
            break;
        }
        int cnt = LinkedList_size(entries);
        if (cnt == 0) break;

        LinkedList elem = LinkedList_getNext(entries);
        while (elem) {
            MmsJournalEntry je = (MmsJournalEntry)elem->data;
            totalEntries++;
            int entryId = totalEntries;

            // 1. Время события
            char timeBuf[64] = "";
            MmsValue* occ = MmsJournalEntry_getOccurenceTime(je);
            if (occ) {
                char rawTime[64];
                MmsValue_printToBuffer(occ, rawTime, sizeof(rawTime));
                format_timestamp(rawTime, timeBuf, sizeof(timeBuf));
            }

            // 2. Переменные записи (значение, качество, время изменения, причина, источник, описание)
            char valueStr[256] = "";
            char qualityStr[64] = "good";
            char changeTimeStr[64] = "";
            char sourceStr[256] = "";
            char descStr[256] = "";
            char reasonStr[64] = "По умолчанию";
            char tagValue[256] = "";
            char tagChangeTime[256] = "";

            LinkedList vars = LinkedList_getNext(je->journalVariables);
            while (vars) {
                MmsJournalVariable var = (MmsJournalVariable)vars->data;
                const char* tag = MmsJournalVariable_getTag(var);
                MmsValue* val = MmsJournalVariable_getValue(var);

                char valStr[256] = "";
                if (val) {
                    switch (MmsValue_getType(val)) {
                        case MMS_BOOLEAN: snprintf(valStr, sizeof(valStr), "%s", MmsValue_getBoolean(val)?"true":"false"); break;
                        case MMS_INTEGER: snprintf(valStr, sizeof(valStr), "%d", MmsValue_toInt32(val)); break;
                        case MMS_UNSIGNED: snprintf(valStr, sizeof(valStr), "%u", MmsValue_toUint32(val)); break;
                        case MMS_FLOAT:   snprintf(valStr, sizeof(valStr), "%f", MmsValue_toFloat(val)); break;
                        default: MmsValue_printToBuffer(val, valStr, sizeof(valStr));
                    }
                }

                // Определяем тип переменной по тегу
                if (strstr(tag, "$stVal") || (strstr(tag, "$mag$f") && !strstr(tag, "$mag$f$t"))) {
                    strcpy(valueStr, valStr);
                    strcpy(tagValue, tag);
                } else if (strstr(tag, "$q")) {
                    strcpy(qualityStr, valStr);
                } else if (strstr(tag, "$t")) {
                    char tmp[64];
                    format_timestamp(valStr, tmp, sizeof(tmp));
                    strcpy(changeTimeStr, tmp);
                    strcpy(tagChangeTime, tag);
                } else if (strstr(tag, "ReasonCode")) {
                    const char* rc_str = reason_code_to_string(valStr);
                    strcpy(reasonStr, rc_str);
                }

                vars = LinkedList_getNext(vars);
            }

            // Если нет явного времени изменения, используем время события
            if (changeTimeStr[0] == '\0') {
                strcpy(changeTimeStr, timeBuf);
            }

            // Извлекаем источник и описание из тега значения
            if (tagValue[0] != '\0') {
                extract_source(tagValue, sourceStr, sizeof(sourceStr));
                extract_description(tagValue, descStr, sizeof(descStr));
            } else if (tagChangeTime[0] != '\0') {
                extract_source(tagChangeTime, sourceStr, sizeof(sourceStr));
                extract_description(tagChangeTime, descStr, sizeof(descStr));
            }

            // 3. Формируем объединённое поле "Значение, качество, время изменения"
            char valueQualityTime[512] = "";
            snprintf(valueQualityTime, sizeof(valueQualityTime), "%s,%s,%s",
                     valueStr, qualityStr, changeTimeStr);

            // 4. Заполняем структуру для callback'а
            LogEntryFullWrapper fullEntry;
            fullEntry.entryId = entryId;
            strncpy(fullEntry.timestamp, timeBuf, sizeof(fullEntry.timestamp)-1);
            fullEntry.timestamp[sizeof(fullEntry.timestamp)-1] = '\0';
            strncpy(fullEntry.reason, reasonStr, sizeof(fullEntry.reason)-1);
            fullEntry.reason[sizeof(fullEntry.reason)-1] = '\0';
            strncpy(fullEntry.source, sourceStr, sizeof(fullEntry.source)-1);
            fullEntry.source[sizeof(fullEntry.source)-1] = '\0';
            strncpy(fullEntry.description, descStr, sizeof(fullEntry.description)-1);
            fullEntry.description[sizeof(fullEntry.description)-1] = '\0';
            strncpy(fullEntry.valueQualityTime, valueQualityTime, sizeof(fullEntry.valueQualityTime)-1);
            fullEntry.valueQualityTime[sizeof(fullEntry.valueQualityTime)-1] = '\0';

            if (g_log_entry_full_callback) {
                g_log_entry_full_callback(&fullEntry);
            }

            elem = LinkedList_getNext(elem);
        }

        // Запоминаем последнюю запись для следующего запроса
        LinkedList lastElem = LinkedList_getLastElement(entries);
        if (lastElem) {
            MmsJournalEntry lastJe = (MmsJournalEntry)lastElem->data;
            if (lastEntry) MmsValue_delete(lastEntry);
            lastEntry = MmsValue_clone(MmsJournalEntry_getEntryID(lastJe));
            lastTimestamp = MmsValue_getUtcTimeInMs(MmsJournalEntry_getOccurenceTime(lastJe));
        }

        LinkedList_destroyDeep(entries, (LinkedListValueDeleteFunction)MmsJournalEntry_destroy);
    }

    if (lastEntry) MmsValue_delete(lastEntry);
    MmsValue_delete(lcbValue);

    char status[128];
    snprintf(status, sizeof(status), "Получено записей: %d, запросов: %d", totalEntries, queryCount);
    if (g_log_status_callback) g_log_status_callback(status);
    client_log("Запрос завершён: %s", status);
}

void client_query_logs_by_time(const char* logRef, uint64_t startTime, uint64_t endTime) {
    (void)startTime; (void)endTime;
    client_log("Фильтр по времени (клиентская сторона)");
    client_query_all_logs(logRef);
}

void client_query_logs_by_entry_id(const char* logRef, int startId, int endId) {
    (void)startId; (void)endId;
    client_log("Фильтр по EntryID (клиентская сторона)");
    client_query_all_logs(logRef);
}

// Запрос модели
void client_refresh_model(void) {
    if (!g_con) {
        client_log("Нет подключения");
        return;
    }
    pthread_t tid;
    pthread_create(&tid, NULL, model_thread_func, NULL);
    pthread_detach(tid);
}

// Поток подключения
static void* client_thread_func(void* arg) {
    const char** params = (const char**)arg;
    const char* host = params[0];
    int port = atoi(params[1]);
    IedClientError error;
    g_con = IedConnection_create();
    client_log("Подключение к %s:%d...", host, port);
    IedConnection_connect(g_con, &error, host, port);
    if (error != IED_ERROR_OK) {
        client_log("Ошибка подключения: %d", error);
        IedConnection_destroy(g_con);
        g_con = NULL;
        g_running = 0;
        return NULL;
    }
    client_log("Подключено к %s:%d", host, port);
    client_detect_logs();
    while (g_running) {
        Thread_sleep(1000);
    }
    client_log("Отключение...");
    IedConnection_close(g_con);
    IedConnection_destroy(g_con);
    g_con = NULL;
    return NULL;
}

int client_connect(const char* hostname, int port) {
    if (g_running) return -1;
    g_running = 1;
    static char host_buf[256];
    static char port_buf[16];
    static const char* params[2];
    strncpy(host_buf, hostname, sizeof(host_buf)-1);
    snprintf(port_buf, sizeof(port_buf), "%d", port);
    params[0] = host_buf;
    params[1] = port_buf;
    pthread_create(&g_client_thread, NULL, client_thread_func, (void*)params);
    return 0;
}

void client_disconnect(void) {
    if (!g_running) return;
    g_running = 0;
    if (g_client_thread) {
#ifdef __linux__
        struct timespec timeout;
        clock_gettime(CLOCK_REALTIME, &timeout);
        timeout.tv_sec += 2;
        pthread_timedjoin_np(g_client_thread, NULL, &timeout);
#else
        pthread_join(g_client_thread, NULL);
#endif
        g_client_thread = 0;
    }
}
